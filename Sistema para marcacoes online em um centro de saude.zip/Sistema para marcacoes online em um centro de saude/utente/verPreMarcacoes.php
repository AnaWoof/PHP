<html>
<head>
  <title>Pre marcacoes</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
</html>
<?php
session_start();
if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
	$sql = "SELECT * FROM premarcacao WHERE paciente = '".$_SESSION["username"]."' and estado = '0'";
	$result = mysqli_query($conn, $sql);
	if (mysqli_num_rows($result) > 0){
		echo "<table border='1' style='text-align:center;'> 				
			<tr>
				<th>ID</th>
				<th>Tipo Marcacao</th>
				<th>Profissional</th>
				<th>Horas</th>
				<th>Data</th>
				<th></th>
				<th></th></td>
			</tr>
				";
		while($row = mysqli_fetch_assoc($result)){
			
			echo "<tr><td>".$row['id_marcacao']."</td>";
			echo "<td>".$row['tipo_marcacao']."</td>";
			echo "<td>".$row['profissional']."</td>";
			echo "<td>".$row['horas']."</td>";
			echo "<td>".$row['data']."</td>";
			
			echo "<td>".'<a href="alterarDadosPreMarcacaoForm.php?id_marcacao='.$row['id_marcacao'].'"><input type="button" value="Alterar">'."</td>";
			echo "<td>".'<a href="apagarPreMarcacaoForm.php?id_marcacao='.$row['id_marcacao'].'"><input type="button" value="Apagar">'."</td></tr>";
		}
	}else{
		echo "Temporariamente Indisponivel";
	}
}	
	echo '<a href="../utente/paginaInicialUtente.php"><input type="button" value="Retroceder">';	

?>