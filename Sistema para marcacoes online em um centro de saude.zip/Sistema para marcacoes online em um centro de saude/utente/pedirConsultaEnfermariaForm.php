<?php
session_start();

if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
	$enfermeiros = mysqli_query($conn, "SELECT username FROM utilizador WHERE tipoUtilizador=3 ORDER BY username ASC");
	$horasServico = mysqli_query($conn, "SELECT horas FROM horas");
}
		?>
<html>
<head>
	<title>Pre-marcacao para enfermaria</title>
	 <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
<form id="form1" name="form1" method="GET" action="../utente/pedirConsultaEnfermaria.php/" )>
   
  <b/><label>Enfermeiro: <?php echo" <select name='enfermeirosLista'>";
					while($row = mysqli_fetch_assoc($enfermeiros)) {
						echo "<option value='" . $row['username'] ."'>" . $row['username'] . "</option>";
					}
					mysqli_data_seek($enfermeiros, 0); 
				echo "</select>"; ?><br>
				
  <b/><label>Data: <input type="date" name="dataConsulta"/><br>
  <b/><label>Hora: <?php echo "<select name='horasLista'>";
					while($row2 = mysqli_fetch_assoc($horasServico)) {
						echo "<option value='" . $row2['horas'] ."'>" . $row2['horas'] . "</option>";
					}
					mysqli_data_seek($horasServico, 0); //faz um reset à query para depois voltar a procurar do 0
				echo "</select>";?><br> 
		  <input type="submit" name="aSubmeter" value="Fazer pre-marcacao">
		  
</body>
</html>