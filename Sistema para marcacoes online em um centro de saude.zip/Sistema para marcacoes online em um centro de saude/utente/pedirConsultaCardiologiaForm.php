<?php
session_start();

if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
	$medicos = mysqli_query($conn, "SELECT username FROM utilizador WHERE tipoUtilizador=2 ORDER BY username ASC");
	$horasServico = mysqli_query($conn, "SELECT horas FROM horas_cardiologia");
}
		?>
<html>
<head>
	<title>Pre-marcacao para dermatologia</title>
	 <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
<form id="form1" name="form1" method="GET" action="pedirConsultaCardiologia.php/" )>

  <b/><label>Medico: <?php echo" <select name='medicosLista'>";
					while($row6 = mysqli_fetch_assoc($medicos)) {
						echo "<option value='" . $row6['username'] ."'>" . $row6['username'] . "</option>";
					}
					mysqli_data_seek($medicos, 0); 
				echo "</select>"; ?><br>
  <b/><label>Data: <input type="date" name="dataConsulta"/><br>
  <b/><label>Hora: <?php echo "<select name='horasLista'>";
					while($row2 = mysqli_fetch_assoc($horasServico)) {
						echo "<option value='" . $row2['horas'] ."'>" . $row2['horas'] . "</option>";
					}
					mysqli_data_seek($horasServico, 0); //faz um reset à query para depois voltar a procurar do 0
				echo "</select>";?><br>     
		 
		  <input type="submit" name="aSubmeter" value="Fazer pre-marcacao">
		
</body>
</html> 