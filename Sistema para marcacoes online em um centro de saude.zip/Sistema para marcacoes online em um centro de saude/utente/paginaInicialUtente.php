<html>
<head>
  <title>Pagina Inicial</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();     
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center> 
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	</div><center>
<h2>Bem vindo utente!</h2>

Dados do centro de saude:

<br><br>Morada: Avenida de Portugal 6000-120 CASTELO BRANCO
<br>Telefone Geral: 272 300 150
<br>Horario de Funcionamento: 9h-12h / 14h-19h
<br>Fax geral:272 340 157
<br>E-mail:geral@cscbranco.pt
<br>Medicos ao servico: <?php 
	include "../basedados.h/basedados.h";
	$result = mysqli_query($conn, "SELECT username FROM utilizador WHERE tipoUtilizador=2");
	while($row = mysqli_fetch_assoc($result)){
	echo $row['username']." | ";
	}
?>
<br>Enfermeiros ao servico: <?php 
	$result = mysqli_query($conn, "SELECT username FROM utilizador WHERE tipoUtilizador=3");
	while($row = mysqli_fetch_assoc($result)){
	echo $row['username']." | ";
	}
?>
<br><br><a href="./gerirDadosPessoais.php">Gerir os meus dados pessoais</a>
<br><a href="./pedirConsultaEnfermariaForm.php">Pedir consulta para enfermaria</a>
<br><a href="./pedirConsultaMedicoForm.php">Pedir consulta para medico</a>
<br><a href="./pedirConsultaDermatologiaForm.php">Pedir consulta para dermatologia</a>
<br><a href="./pedirConsultaCardiologiaForm.php">Pedir consulta para cardiologia</a>
<br><a href="./verConsultasMarcadas.php">Ver as minhas consultas marcadas</a>
<br><a href="./verPreMarcacoes.php">Ver as minhas pre-marcacoes</a>
<br><a href="./verHistoricoConsultas.php">Ver historico de consultas</a>



<br><br><a href="../login/logout.php"><input type="button" value="Logout">

</body>
</html>