<?php
	ob_start(); 
	include "../basedados.h/basedados.h";
	
	$utilizador = $_GET['login_username'];
	$password = $_GET['login_password'];
	$dadosLogin = mysqli_query($conn, "SELECT username, password, tipoUtilizador, estado FROM Utilizador ");
	$linha = mysqli_fetch_assoc($dadosLogin);
	$estado = false; 
	
	do {
	    if($linha['username'] == $utilizador && $linha['password'] == $password  && $linha['estado'] == 1){		
		     $tipoUtilizador=$linha['tipoUtilizador'];
		     $podeEntrar=true;
			 session_start();
		$_SESSION['tipoUtilizador']=$tipoUtilizador;
		$_SESSION['username']=$utilizador;
		}
			
	}while ($linha = mysqli_fetch_assoc($dadosLogin));
	
	if ((true)&& isset($_SESSION['tipoUtilizador'])){
		
	   
		if($tipoUtilizador==1){
				?>
				<script language="javascript">setTimeout(function(){window.location.href='../admin/paginaInicialAdmin.php'},0000);</script>
				<?php
			}else if ($tipoUtilizador==2){
				?>
				<script language="javascript">setTimeout(function(){window.location.href='../medico/paginaInicialMedico.php'},0000);</script>
				<?php
			}else if ($tipoUtilizador==3){
				?>
				<script language="javascript">setTimeout(function(){window.location.href='../enfermeiro/paginaInicialEnfermeiro.php'},0000);</script>
				<?php
			}else if ($tipoUtilizador==4){
				?>
				<script language="javascript">setTimeout(function(){window.location.href='../funcionario/paginaInicialFuncionario.php'},0000);</script>
				<?php
			}else if ($tipoUtilizador==5){
				?>
				<script language="javascript">setTimeout(function(){window.location.href='../utente/paginaInicialUtente.php'},0000);</script>
				<?php
			}else {
				?>
				<script language="javascript">setTimeout(function(){window.location.href='../paginaInicial.html'},0000);</script>
				<?php
			}
			
	}
	else {
			echo " Login errado " ;
			?>
				<script language="javascript">setTimeout(function(){window.location.href='./login_form.html'},2000);</script>
				<?php
	}
?>

