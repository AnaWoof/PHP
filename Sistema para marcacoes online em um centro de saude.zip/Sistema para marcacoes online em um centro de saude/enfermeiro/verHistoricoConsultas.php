<html>
<head>
  <title>Historico de Consultas</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
</html>


<?php 
session_start();
if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
	$sql = "SELECT * FROM marcacao WHERE estado = '1' AND tipo_marcacao = '1' AND profissional = '".$_SESSION["username"]."'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0){
		echo "<table border='1' style='text-align:center;'> 				
			<tr>
				<th>Id</th>
				<th>Paciente</th>
				<th>Estado</th>
				<th>Profissional</th>
				<th>Horas</th>
				<th>Data</th></td>

			</tr>";
			
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr><td>".$row['id_marcacao']."</td>";
			echo "<td>".$row['paciente']."</td>";
			echo "<td>".$row['estado']."</td>";
			echo "<td>".$row['profissional']."</td>";
			echo "<td>".$row['horas']."</td>";
			echo "<td>".$row['data']."</td>";
			
		}
		
	}else{
		echo "Sem consultas realizadas";
	}
}	
	echo '<a href="../enfermeiro/paginaInicialEnfermeiro.php"><input type="button" value="Retroceder">';	

?>