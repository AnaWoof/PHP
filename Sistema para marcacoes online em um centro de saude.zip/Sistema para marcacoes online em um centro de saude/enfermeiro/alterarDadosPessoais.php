<?php
session_start();

if(isset($_SESSION["username"])){
	$password = $_GET['password'];
	$telemovel = $_GET ['telemovel'];
	$dataNascimento = $_GET['dataNascimento'];
	$nacionalidade = $_GET['nacionalidade'];
	$naturalidade = $_GET['naturalidade'];
	$email = $_GET['email'];
	$morada = $_GET['morada'];

	include "../basedados.h/basedados.h";
	
	$sql = "UPDATE utilizador SET morada='$morada',telemovel='$telemovel', dataNascimento='$dataNascimento', naturalidade='$naturalidade', nacionalidade='$nacionalidade', email='$email' WHERE username = '".$_SESSION["username"]."'"; 
$retval = mysqli_query($conn , $sql);

if (mysqli_affected_rows ($conn) == 1)
	echo ('<font color="green">Dados alterados com sucesso!!!</font>');
else
	echo ('<font color="red">Não foi possivel alterar os seus dados!!!</font>');
header ('refresh:2;url=../enfermeiro/gerirDadosPessoais.php');
}
?>