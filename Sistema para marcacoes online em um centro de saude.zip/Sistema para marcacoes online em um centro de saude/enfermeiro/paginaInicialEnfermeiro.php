<html>
<head>
  <title>Pagina Inicial</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
	<h2>Bem vindo enfermeiro!</h2>
	
<a href="../enfermeiro/gerirDadosPessoais.php">Gerir os meus dados pessoais</a>
<br><a href="../enfermeiro/verConsultasMarcadas.php">Ver consultas marcadas</a>
<br><a href="../enfermeiro/verHistoricoConsultas.php">Ver historico de consultas realizadas</a>
<br><a href="../enfermeiro/verConsultasMarcadasTodosEnfermeiros.php">Ver consultas marcadas para todos os enfermeiros</a>
<br><br><a href="../login/logout.php"><input type="button" value="Logout">

</body>
</html>