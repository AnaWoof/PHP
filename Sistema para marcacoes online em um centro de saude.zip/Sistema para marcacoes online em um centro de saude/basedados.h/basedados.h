<?php	
	$hostname_conn = "localhost"; //nomes da ficha5
	$database_conn = "centrosaudephp";
	$USER_BD = "root";
	$PASS_BD = "";
	
// Conectamos ao nosso servidor MySQL
if(!($conn = mysqli_connect($hostname_conn, $USER_BD, $PASS_BD))) 
{
   echo "Erro ao conectar ao MySQL.";
   exit;
}
// Selecionamos nossa base de dados MySQL
if(!($con = mysqli_select_db($conn, $database_conn))) {
   echo "Erro ao selecionar ao MySQL.";
   exit;
} else {
	$_SESSION['conn']=$conn; 
}
?>