<?php
session_start();

if(isset($_SESSION["username"])){
	$paciente = $_GET['paciente'];
    $estado = $_GET ['estado'];
	include "../basedados.h/basedados.h";
	
	$sql = "UPDATE marcacao SET estado='$estado' WHERE paciente = '$paciente'"; 
    echo $sql;
	exit;
	$retval = mysqli_query($conn , $sql);

	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Dados alterados com sucesso!!!</font>');
	else
		echo ('<font color="red">Nao foi possivel alterar os seus dados!!!</font>');
	header ('refresh:2;url=verConsultasMarcadas.php');
}
?>