<html>
<head>
  <title>Pagina Inicial</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();     
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center> 
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	</div><center>
<h2>Bem vindo medico!</h2>

<a href="../medico/gerirDadosPessoais.php">Gerir os meus dados pessoais</a>
<br><a href="../medico/verConsultasMarcadas.php">Ver consultas marcadas</a>
<br><a href="../medico/verHistoricoConsultas.php">Ver historico de consultas realizadas</a>
<br><a href="../medico/verConsultasMarcadasTodosMedicos.php">Ver consultas marcadas para todos os medicos</a>

<br><br><a href="../login/logout.php"><input type="button" value="Logout">

</body>
</html>