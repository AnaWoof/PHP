<?php
session_start();
		

if(isset($_SESSION["username"])&& $_SESSION["tipoUtilizador"]=='1'){
	$id_marcacao = $_GET['id_marcacao'];
	$paciente = $_GET ['paciente'];
	$tipo_marcacao = $_GET['tipo_marcacao'];
	$profissional = $_GET['profissional'];
	$horas = $_GET['horas'];
	$data = $_GET['data'];
	$estado = $_GET['estado'];

	include "../basedados.h/basedados.h";
	
	$sql = "DELETE FROM marcacao WHERE id_marcacao = '".$_GET["id_marcacao"]."'"; 
	$retval = mysqli_query($conn , $sql);

	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Marcacao apagada com sucesso!!!</font>');
	else
		echo ('<font color="red">Não foi possivel remover a marcacao!!!</font>');
	header ('refresh:2;url=../admin/gerirMarcacoes.php');
}
?>