<html>
<head>
  <title>Pagina Inicial</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();     
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center> 
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	</div><center>
<h2>Bem vindo administrador!</h2>

<br><a href="../admin/gerirDadosPessoais.php">Gerir os meus dados pessoais</a>
<br><a href="../admin/gerirUtilizadores.php">Gerir os dados pessoais dos utilizadores</a>
<br><a href="../admin/gerirPreMarcacoes.php">Gerir pre-marcacoes</a>
<br><a href="../admin/gerirMarcacoes.php">Gerir marcacoes</a>

<br><br><a href="../login/logout.php"><input type="button" value="Logout">

</body>
</html>