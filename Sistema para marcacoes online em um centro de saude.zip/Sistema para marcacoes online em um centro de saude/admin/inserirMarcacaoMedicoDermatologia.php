<?php
	$paciente = $_GET['utenteLista'];
	$tipo_marcacao = $_GET['tipo_marcacao']='3';
	$profissional = $_GET['medicoLista'];
	$horas = $_GET['horasLista'];
	$data = $_GET['data'];
	$estado = $_GET['estado']=0;

	include "../basedados.h/basedados.h";
	
		$sql = "INSERT INTO marcacao (  paciente, tipo_Marcacao, profissional, horas, data,estado) VALUES ( '$paciente', '3','$profissional', '$horas', '$data','0' )";
		$selec = mysqli_query($conn, $sql );
		
		if (mysqli_affected_rows ($conn) == 1)
			echo ('<font color="green">Consulta inserida com sucesso!</font>');
		else
			echo ('<font color="red">Ocorreu um problema com a introducao da consulta!</font>');
		header ('refresh:2;url=../admin/gerirMarcacoes.php');
	
?>