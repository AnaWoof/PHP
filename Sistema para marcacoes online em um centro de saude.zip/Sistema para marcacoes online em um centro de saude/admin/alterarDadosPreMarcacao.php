<?php
session_start();

if(isset($_SESSION["username"])){
	$id_marcacao = $_GET['id_marcacao'];
	$paciente = $_GET['paciente'];
	$tipo_marcacao = $_GET ['tipo_marcacao'];
	$profissional = $_GET['profissional'];
	$horas = $_GET['horas'];
	$data = $_GET['data'];
	include "../basedados.h/basedados.h";
	
	$sql = "UPDATE premarcacao SET paciente='$paciente', tipo_marcacao='$tipo_marcacao', profissional='$profissional', horas='$horas', data='$data' WHERE id_marcacao='$id_marcacao';"; 
	
	$retval = mysqli_query($conn , $sql);

	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Dados alterados com sucesso!!!</font>');
	else
		echo ('<font color="red">Nao foi possivel alterar os seus dados!!!</font>');
	header ('refresh:2;url=gerirPreMarcacoes.php');
}
?>