<html>
<head>
  <title>Gerir Utilizadores</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();     
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center> 
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	</div><center>
</body>
</html>

<?php
	session_start();
	include "../basedados.h/basedados.h";
	$result = mysqli_query($conn, "SELECT * FROM utilizador");

	if (mysqli_num_rows($result) > 0){
		echo "<table border='1' style='text-align:center;'> 		
				<th>Nome</th>
				<th>Password</th>
				<th>Morada</th>
				<th>Telemovel</th>
				<th>Data de Nascimento</th>
				<th>Naturalidade</th>
				<th>Nacionalidade</th>
				<th>Email</th>
				<th>Estado</th>
				<th></th>
				<th></td>
			</tr>
				";
				  
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr><td>".$row['username']."</td>";
			echo "<td>".$row['password']."</td>";
			echo "<td>".$row['morada']."</td>";
			echo "<td>".$row['telemovel']."</td>";
			echo "<td>".$row['dataNascimento']."</td>";
			echo "<td>".$row['naturalidade']."</td>";
			echo "<td>".$row['nacionalidade']."</td>";
			echo "<td>".$row['email']."</td>";
			echo "<td>".$row['estado']."</td>";
			echo "<td>".'<a href="../admin/apagarUserForm.php?username='.$row['username'].'">apagar'. "</td>";
			echo "<td>".'<a href="../admin/alterarDadosForm.php?username='.$row['username'].'">alterar'."</td></tr>";
		}
	}else{
		echo "Temporariamente Indisponivel";
	}
	echo '<a href="../admin/inserirUserForm.php"><input type="button" value="Inserir utente">';
	echo '<a href="../admin/inserirUserMedicoForm.php"><input type="button" value="Inserir medico">';
	echo '<a href="../admin/inserirUserEnfermeiroForm.php"><input type="button" value="Inserir enfermeiro">';
	echo '<a href="../admin/inserirUserFuncionarioForm.php"><input type="button" value="Inserir funcionario">';
	echo '<a href="../admin/inserirUserAdminForm.php"><input type="button" value="Inserir admin">';
	echo '<a href="../admin/paginaInicialAdmin.php"><input type="button" value="Retroceder">';
?>