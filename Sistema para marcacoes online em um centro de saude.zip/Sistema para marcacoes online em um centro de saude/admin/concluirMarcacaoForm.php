<html>
<head>
  <title>Aceitar Marcacao</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
</html>

<?php
session_start();

if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
	$sql = "SELECT * FROM marcacao WHERE id_marcacao = '".$_GET["id_marcacao"]."'";
	$result = mysqli_query($conn,$sql );

	if (mysqli_num_rows($result) > 0){
		$row=mysqli_fetch_array($result);
		}
}
?>
		
<html>
<body>
 <form id="form1" name="form1" method="GET" action="concluirMarcacao.php">
 
 <b/><label>Id da marcacao: <input type="text" name="id_marcacao" value="<?php echo $row['id_marcacao'];?>" /><br>
 <b/><label>Paciente: <input type="text" name="paciente" value="<?php echo $row['paciente'];?>" /><br>
 <b/><label>Tipo de marcacao: <input type="text" name="tipo_marcacao" value="<?php echo $row['tipo_marcacao'];?>" /><br>
 <b/><label>Profissional: <input type="text" name="profissional" value="<?php echo $row['profissional'];?>" /><br>
 <b/><label>Horas: <input type="text" name="horas" value="<?php echo $row['horas'];?>" /><br>
 <b/><label>Data: <input type="date" name="data" value="<?php echo $row['data'];?>" /><br>
 
  <input type="submit" name="Submit" value="Concluir consulta" >
	<BR>
</body>
</html>