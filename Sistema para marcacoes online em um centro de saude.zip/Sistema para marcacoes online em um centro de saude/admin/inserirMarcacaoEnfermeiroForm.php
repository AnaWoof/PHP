<?php
session_start();

if(isset($_SESSION["username"])){
	include"../basedados.h/basedados.h";
	
	$utentes = mysqli_query($conn, "SELECT username FROM utilizador WHERE tipoUtilizador=5 ORDER BY username ASC");
	$profissionais = mysqli_query($conn, "SELECT username FROM utilizador WHERE tipoUtilizador=3 ORDER BY username ASC");
	$horasServico = mysqli_query($conn, "SELECT horas FROM horas");
}
		?>

<html>
<head>
  <title>Nova marcacao Enfermeiro</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
	
<form id="form1" name="form1" method="GET" action="inserirMarcacaoEnfermeiro.php">
  <b/><label>Paciente: <?php echo "<select name='utenteLista'>";
					while($row2 = mysqli_fetch_assoc($utentes)) {
						echo "<option value='" . $row2['username'] ."'>" . $row2['username'] . "</option>";
					}
					mysqli_data_seek($utentes, 0); 
				echo "</select>";?><br>
  <b/><label>Profissional: <?php echo" <select name='enfermeiroLista'>";
					while($row3 = mysqli_fetch_assoc($profissionais)) {
						echo "<option value='" . $row3['username'] ."'>" . $row3['username'] . "</option>";
					}
					mysqli_data_seek($profissionais, 0); 
				echo "</select>"; ?><br>
  <b/><label>Horas: <?php echo "<select name='horasLista'>";
					while($row4 = mysqli_fetch_assoc($horasServico)) {
						echo "<option value='" . $row4['horas'] ."'>" . $row4['horas'] . "</option>";
					}
					mysqli_data_seek($horasServico, 0); //faz um reset à query para depois voltar a procurar do 0
				echo "</select>";?><br>
  <b/><label>Data: <input type="date" name="data"/><br>
 
 
  <input type="submit" name="Submit" value="Inserir" 
	<BR>
</body>
</html>