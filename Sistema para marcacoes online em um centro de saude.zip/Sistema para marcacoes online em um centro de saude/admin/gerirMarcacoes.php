<html>
<head>
  <title>Gerir marcacoes</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();     
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center> 
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	</div><center>
</body>
</html>

<?php
	session_start();
	include "../basedados.h/basedados.h";
	$result = mysqli_query($conn, "SELECT * FROM marcacao");

	if (mysqli_num_rows($result) > 0){
		echo "<table border='1' style='text-align:center;'> 		
				<th>id marcacao</th>
				<th>paciente</th>
				<th>tipo marcacao</th>
				<th>profissional</th>
				<th>horas</th>
				<th>data</th>
				<th>estado</th>
				<th></th>
				<th></th>
				<th></td>
			</tr>
				";
				  
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr><td>".$row['id_marcacao']."</td>";
			echo "<td>".$row['paciente']."</td>";
			echo "<td>".$row['tipo_marcacao']."</td>";
			echo "<td>".$row['profissional']."</td>";
			echo "<td>".$row['horas']."</td>";
			echo "<td>".$row['data']."</td>";
			echo "<td>".$row['estado']."</td>";
			echo "<td>".'<a href="../admin/concluirMarcacaoForm.php?id_marcacao='.$row['id_marcacao'].'">Concluir consulta'. "</td>";
			echo "<td>".'<a href="../admin/apagarMarcacaoForm.php?id_marcacao='.$row['id_marcacao'].'">Apagar marcacao'. "</td>";
			echo "<td>".'<a href="../admin/alterarDadosMarcacaoForm.php?id_marcacao='.$row['id_marcacao'].'">Alterar dados'."</td></tr>";
		}
	}else{
		echo "Nao ha pre-marcacoes.";
	}
		echo '<a href="../admin/inserirMarcacaoEnfermeiroForm.php"><input type="button" value="Inserir nova marcacao enfermeiro">';
		echo '<a href="../admin/inserirMarcacaoMedicoForm.php"><input type="button" value="Inserir nova marcacao medico">';
		echo '<a href="../admin/inserirMarcacaoMedicoDermatologiaForm.php"><input type="button" value="Inserir nova marcacao dermatologia">';
		echo '<a href="../admin/inserirMarcacaoMedicoCardiologiaForm.php"><input type="button" value="Inserir nova marcacao cardiologia">';
		echo '<a href="../admin/paginaInicialAdmin.php"><input type="button" value="Retroceder">';
?>