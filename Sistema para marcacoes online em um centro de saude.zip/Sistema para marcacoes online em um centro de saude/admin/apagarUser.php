<?php
session_start();
		

if(isset($_SESSION["username"])&& $_SESSION["tipoUtilizador"]=='1'){
	$password = $_GET['password'];
	$telemovel = $_GET ['telemovel'];
	$dataNascimento = $_GET['dataNascimento'];
	$nacionalidade = $_GET['nacionalidade'];
	$naturalidade = $_GET['naturalidade'];
	$email = $_GET['email'];
	$morada = $_GET['morada'];

	include "../basedados.h/basedados.h";
	
	$sql = "DELETE FROM utilizador WHERE username = '".$_GET["username"]."'"; 
	$retval = mysqli_query($conn , $sql);

	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Utilizador apagado com sucesso!!!</font>');
	else
		echo ('<font color="red">Não foi possivel remover o utilizador!!!</font>');
	header ('refresh:2;url=../admin/gerirUtilizadores.php');
}
?>