-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 21-Jun-2017 às 14:18
-- Versão do servidor: 10.1.10-MariaDB
-- PHP Version: 7.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `centrosaudephp`
--
CREATE DATABASE IF NOT EXISTS `centrosaudephp` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `centrosaudephp`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `horas`
--

CREATE TABLE `horas` (
  `horas` time NOT NULL,
  `id_horas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `horas`
--

INSERT INTO `horas` (`horas`, `id_horas`) VALUES
('09:00:00', 1),
('09:30:00', 2),
('10:00:00', 3),
('10:30:00', 4),
('11:00:00', 5),
('11:30:00', 6),
('12:00:00', 7),
('14:00:00', 8),
('14:30:00', 9),
('15:00:00', 10),
('15:30:00', 11),
('16:00:00', 12),
('16:30:00', 13),
('17:00:00', 14),
('17:30:00', 15),
('18:00:00', 16),
('18:30:00', 17),
('19:00:00', 18);

-- --------------------------------------------------------

--
-- Estrutura da tabela `horas_cardiologia`
--

CREATE TABLE `horas_cardiologia` (
  `horas` time NOT NULL,
  `id_horas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `horas_cardiologia`
--

INSERT INTO `horas_cardiologia` (`horas`, `id_horas`) VALUES
('10:00:00', 1),
('12:00:00', 2),
('14:00:00', 3),
('16:00:00', 4),
('18:00:00', 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `horas_dermatologia`
--

CREATE TABLE `horas_dermatologia` (
  `horas` time NOT NULL,
  `id_horas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `horas_dermatologia`
--

INSERT INTO `horas_dermatologia` (`horas`, `id_horas`) VALUES
('09:00:00', 1),
('11:00:00', 2),
('14:00:00', 3),
('16:00:00', 4),
('18:00:00', 5);

-- --------------------------------------------------------

--
-- Estrutura da tabela `marcacao`
--

CREATE TABLE `marcacao` (
  `id_marcacao` int(11) NOT NULL,
  `profissional` varchar(20) NOT NULL,
  `paciente` varchar(40) NOT NULL,
  `tipo_marcacao` tinyint(4) NOT NULL,
  `horas` time NOT NULL,
  `data` date NOT NULL,
  `estado` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `premarcacao`
--

CREATE TABLE `premarcacao` (
  `id_marcacao` int(11) NOT NULL,
  `paciente` varchar(40) NOT NULL,
  `tipo_marcacao` tinyint(4) NOT NULL,
  `profissional` varchar(20) NOT NULL,
  `horas` time NOT NULL,
  `data` date NOT NULL,
  `estado` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `tipo_utilizador`
--

CREATE TABLE `tipo_utilizador` (
  `idTipoUtilizador` int(11) NOT NULL,
  `descricao` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tipo_utilizador`
--

INSERT INTO `tipo_utilizador` (`idTipoUtilizador`, `descricao`) VALUES
(1, 'admin'),
(2, 'medico'),
(3, 'enfermeiro'),
(4, 'funcionario'),
(5, 'utente');

-- --------------------------------------------------------

--
-- Estrutura da tabela `utilizador`
--

CREATE TABLE `utilizador` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `morada` varchar(30) NOT NULL,
  `telemovel` int(9) NOT NULL,
  `dataNascimento` date NOT NULL,
  `naturalidade` varchar(30) NOT NULL,
  `nacionalidade` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tipoUtilizador` int(11) NOT NULL,
  `estado` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `utilizador`
--

INSERT INTO `utilizador` (`username`, `password`, `morada`, `telemovel`, `dataNascimento`, `naturalidade`, `nacionalidade`, `email`, `tipoUtilizador`, `estado`) VALUES
('admin', 'admin', 'Rua P', 968888888, '2017-06-09', 'Lisboa', 'Portugal', 'admin@admin.pt', 1, 1),
('enfermeiro', 'enfermeiro', 'Rua C', 964444444, '2017-06-11', 'Castelo Branco', 'Portugal', 'enfermeiro@enfermeiro.pt', 3, 1),
('funcionario', 'funcionario', 'Rua c', 969999999, '1975-01-16', 'Lisboa', 'Portugal', 'funcionario@funcionario.pt', 4, 1),
('medico', 'medico', 'Rua E', 995555555, '1984-06-21', 'silvares', 'Portugal', 'medico@medico.pt', 2, 1),
('utente', 'utente', 'Rua E', 914522222, '2017-06-12', 'Fundao', 'Portugal', 'utente@utente.pt', 5, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `horas`
--
ALTER TABLE `horas`
  ADD PRIMARY KEY (`id_horas`);

--
-- Indexes for table `marcacao`
--
ALTER TABLE `marcacao`
  ADD PRIMARY KEY (`id_marcacao`);

--
-- Indexes for table `premarcacao`
--
ALTER TABLE `premarcacao`
  ADD PRIMARY KEY (`id_marcacao`);

--
-- Indexes for table `tipo_utilizador`
--
ALTER TABLE `tipo_utilizador`
  ADD PRIMARY KEY (`idTipoUtilizador`);

--
-- Indexes for table `utilizador`
--
ALTER TABLE `utilizador`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `username_2` (`username`),
  ADD KEY `tipoUtilizador_fk` (`tipoUtilizador`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `horas`
--
ALTER TABLE `horas`
  MODIFY `id_horas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `marcacao`
--
ALTER TABLE `marcacao`
  MODIFY `id_marcacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `premarcacao`
--
ALTER TABLE `premarcacao`
  MODIFY `id_marcacao` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
