<html>
<head>
  <title>Gerir marcacoes para medico</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
</html>
<?php 
session_start();
if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
		$result = mysqli_query($conn, "SELECT * FROM marcacao WHERE estado='0' AND tipo_marcacao!='1'");
	
	if (mysqli_num_rows($result) > 0){
		echo "<table border='1' style='text-align:center;'> 				
			<tr>
				<th>ID da Marcacao</th>
				<th>Paciente</th>
				<th>Tipo de Marcacao</th>
				<th>Medico</th>
				<th>Horas</th>
				<th>Data</th>
				<th></td>
				<th></td>
				<th></td>
			</tr>";
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr><td>".$row['id_marcacao']."</td>";
			echo "<td>".$row['paciente']."</td>";
			echo "<td>".$row['tipo_marcacao']."</td>";
			echo "<td>".$row['profissional']."</td>";	
			echo "<td>".$row['horas']."</td>";
			echo "<td>".$row['data']."</td>";
			echo "<td>".'<a href="../funcionario/concluirMarcacaoMedicoForm.php?id_marcacao='.$row['id_marcacao'].'"><input type="button" value="concluir">'. "</td>";
			echo "<td>".'<a href="../funcionario/alterarMarcacaoMedicoForm.php?id_marcacao='.$row['id_marcacao'].'"><input type="button" value="alterar">'. "</td>";
			echo "<td>".'<a href="../funcionario/recusarMarcacaoMedicoForm.php?id_marcacao='.$row['id_marcacao'].'"><input type="button" value="recusar">'."</td></tr>";
		}
	}else{
		echo "Nao existem marcacoes.";
	}
}

echo '<a href="../funcionario/paginaInicialFuncionario.php"><input type="button" value="Retroceder">';
?>