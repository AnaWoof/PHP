<html>
<head>
	<title>Inserir medico</title>
	 <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
<form id="form1" name="form1" method="GET" action="inserirUserMedico.php">

  <b/><label>Nome: <input type="text" name="username"/> <br> 
  <b/><label>Password: <input type="text" name="password"/><br>
  <b/><label>Morada: <input type="text" name="morada"/><br>
  <b/><label>Telemovel: <input type="text" name="telemovel"/><br>
  <b/><label>Data de Nascimento: <input type="date" name="dataNascimento"/><br>
  <b/><label>Naturalidade: <input type="text" name="naturalidade"/><br>
  <b/><label>Nacionalidade: <input type="text" name="nacionalidade"/><br>
  <b/><label>Email: <input type="text" name="email"/><br>
 
		  <input type="submit" name="Submit" value="Inserir novo Medico">
		
</body>
</html>