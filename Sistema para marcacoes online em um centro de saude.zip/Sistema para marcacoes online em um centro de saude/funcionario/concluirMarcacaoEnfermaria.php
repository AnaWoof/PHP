<?php
session_start();

if(isset($_SESSION["username"])){
	$id_marcacao = $_GET['id_marcacao'];
	$paciente = $_GET['paciente'];
	$profissional = $_GET['enfermeiro'];
	$horas = $_GET['horas'];
	$data = $_GET['data'];
    $estado = 1;
	include "../basedados.h/basedados.h";
	
	$sql = "UPDATE marcacao SET estado='1' WHERE id_marcacao = '".$_GET["id_marcacao"]."'"; 
	
	$retval = mysqli_query($conn , $sql);

	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Consulta concluida com sucesso!!!</font>');
	else
		echo ('<font color="red">Nao foi possivel concluir a consulta!!!</font>');
	header ('refresh:2;url=gerirMarcacoesEnfermaria.php');
}
?>