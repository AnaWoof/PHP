<?php
session_start();

if(isset($_SESSION["username"])){
	$id_marcacao = $_GET['id_marcacao'];
	$paciente = $_GET['paciente'];
	$profissional = $_GET['enfermeiro'];
	$horas = $_GET['horas'];
	$data = $_GET['data'];
    $estado = 1;
	include "../basedados.h/basedados.h";
	
	$sql = "UPDATE premarcacao SET estado='1' WHERE id_marcacao = '".$_GET["id_marcacao"]."'"; 
	
	$sql2 = "INSERT INTO marcacao ( paciente, tipo_marcacao, estado, profissional, horas, data) VALUES ( '$paciente', '1', '0', '$profissional', '$horas', '$data')";

	$retval = mysqli_query($conn , $sql);
	$retval = mysqli_query($conn , $sql2);


	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Consulta aceite com sucesso!!!</font>');
	else
		echo ('<font color="red">Nao foi possivel aceitar a consulta!!!</font>');
	header ('refresh:2;url=gerirPreMarcacoesEnfermaria.php');
}
?>