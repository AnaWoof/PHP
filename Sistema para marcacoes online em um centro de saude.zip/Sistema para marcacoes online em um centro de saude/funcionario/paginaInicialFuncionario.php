<html>
<head>
  <title>Pagina Inicial</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
	<h2>Bem vindo funcionario!</h2>

<a href="./gerirDadosPessoais.php">Gerir os meus dados pessoais</a>
<br><a href="./gerirPreMarcacoesEnfermaria.php">Gerir pre-marcacoes para enfermaria</a>
<br><a href="./gerirPreMarcacoesMedico.php">Gerir pre-marcacoes para medico</a>
<br><a href="./gerirMarcacoesEnfermaria.php">Gerir marcacoes para enfermaria</a>
<br><a href="./gerirMarcacoesMedico.php">Gerir marcacoes para medico</a>

<br><br><a href="./inserirMarcacaoMedicoForm.php">Inserir marcacao para medico</a>
<br><a href="./inserirMarcacaoMedicoDermatologiaForm.php">Inserir marcacao para dermatologia</a>
<br><a href="./inserirMarcacaoMedicoCardiologiaForm.php">Inserir marcacao para cardiologia</a>
<br><a href="./inserirMarcacaoEnfermariaForm.php">Inserir marcacao para enfermaria</a>

<br><br><a href="./inserirPreMarcacaoMedicoForm.php">Inserir pre-marcacao para medico</a>
<br><a href="./inserirPreMarcacaoMedicoDermatologiaForm.php">Inserir pre-marcacao para dermatologia</a>
<br><a href="./inserirPreMarcacaoMedicoCardiologiaForm.php">Inserir pre-marcacao para cardiologia</a>
<br><a href="./inserirPreMarcacaoEnfermeiroForm.php">Inserir pre-marcacao para enfermaria</a>

<br><br><a href="./inserirUserFuncionarioForm.php">Inserir novo funcionario</a>
<br><a href="./inserirUserMedicoForm.php">Inserir novo medico</a>
<br><a href="./inserirUserEnfermeiroForm.php">Inserir novo enfermeiro</a>
<br><br><a href="../login/logout.php"><input type="button" value="logout">

</body>
</html>