<?php
session_start();

if(isset($_SESSION["username"])){
	$id_marcacao = $_GET['id_marcacao'];
	$tipo_marcacao = $_GET['tipo_marcacao'];
	$paciente = $_GET ['paciente'];
	$profissional = $_GET['profissional'];
	$horas = $_GET['horas'];
	$data = $_GET['data'];
	include "../basedados.h/basedados.h";
	
	$sql = "UPDATE premarcacao SET estado='1' WHERE id_marcacao = '$id_marcacao';"; 
	
	$sql2 = "INSERT INTO marcacao ( paciente, tipo_marcacao, profissional, horas, data, estado) VALUES ( '$paciente', '$tipo_marcacao', '$profissional', '$horas', '$data', '1')";

	$retval = mysqli_query($conn , $sql);
	$retval = mysqli_query($conn , $sql2);


	if (mysqli_affected_rows ($conn) == 1)
		echo ('<font color="green">Dados alterados com sucesso!!!</font>');
	else
		echo ('<font color="red">Nao foi possivel alterar os seus dados!!!</font>');
	header ('refresh:2;url=gerirPreMarcacoesMedico.php');
}
?>