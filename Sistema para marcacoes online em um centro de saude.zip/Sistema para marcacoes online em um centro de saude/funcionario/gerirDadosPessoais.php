<html>
<head>
  <title>Gerir Dados Pessoais</title>
  <script>
function timer()
{
        var d = new Date();
        document.getElementById('date').innerHTML = d.toLocaleTimeString();
       
        setTimeout('timer()', 1000);
}
</script>
</head>
<body>
<body onLoad="timer()"><center>
<div id="date"></div><center>
	<div id="banner">
		<div class="image"><a href="#"><img src="../img/logo.jpg" width="1000" height="262" alt="" /></a></div>
	 </a>
	</div><center>
</body>
</html>


<?php 
session_start();
if(isset($_SESSION["username"])){
	include "../basedados.h/basedados.h";
	
	$sql = "SELECT* FROM utilizador WHERE username = '".$_SESSION["username"]."'";
	$result = mysqli_query($conn, $sql);

	if (mysqli_num_rows($result) > 0){
		echo "<table border='1' style='text-align:center;'> 				
			<tr>
				<th>Nome</th>
				<th>Password</th>
				<th>Morada</th>
				<th>Telemovel</th>
				<th>Data de Nascimento</th>
				<th>Naturalidade</th>
				<th>Nacionalidade</th>
				<th>Email</th>
				<th>Estado</th>
				<th></td>
			</tr>
				";
		while($row = mysqli_fetch_assoc($result)){
			echo "<tr><td>".$row['username']."</td>";
			echo "<td>".$row['password']."</td>";
			echo "<td>".$row['morada']."</td>";
			echo "<td>".$row['telemovel']."</td>";
			echo "<td>".$row['dataNascimento']."</td>";
			echo "<td>".$row['naturalidade']."</td>";
			echo "<td>".$row['nacionalidade']."</td>";
			echo "<td>".$row['email']."</td>";
			echo "<td>".$row['estado']."</td>";
			
			echo "<td>".'<a href="../funcionario/alterarDadosPessoaisForm.php"><input type="button" value="Alterar">'."</td></tr>";
		}
	}else{
		echo "Temporariamente Indisponivel";
	}
}	
	echo '<a href="../funcionario/paginaInicialFuncionario.php"><input type="button" value="Retroceder">';
?>
