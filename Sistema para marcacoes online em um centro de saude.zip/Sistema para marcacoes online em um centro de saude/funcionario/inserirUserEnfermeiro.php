<?php
	
	$username = $_GET['username'];
	$password = $_GET['password'];
	$telemovel = $_GET['telemovel'];
	$dataNascimento = $_GET['dataNascimento'];
	$nacionalidade = $_GET['nacionalidade'];
	$naturalidade = $_GET['naturalidade'];
	$morada = $_GET['morada'];
	$email = $_GET['email'];
	$tipoUtilizador = ['tipoUtilizador'];
	$estado = 1;
	include "../basedados.h/basedados.h";
	
		$sql = "INSERT INTO utilizador ( username, password, telemovel, dataNascimento, nacionalidade, naturalidade, morada, email, tipoUtilizador, estado) VALUES ( '$username', '$password', '$telemovel', '$dataNascimento', '$nacionalidade', '$naturalidade', '$morada','$email',' 3 ', '$estado')";
		$retval = mysqli_query($conn, $sql );
		
		if (mysqli_affected_rows ($conn) == 1)
			echo ('<font color="green">INSERT com sucesso!!!</font>');
		else
			echo ('<font color="red">INSERT falhou!!!</font>');
		header ('refresh:2;url=../funcionario/paginaInicialFuncionario.php');
	
?>