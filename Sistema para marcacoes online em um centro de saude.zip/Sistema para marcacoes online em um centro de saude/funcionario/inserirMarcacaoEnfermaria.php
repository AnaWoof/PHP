<?php
	$paciente = $_GET['utenteLista'];
	$tipo_marcacao = $_GET['tipo_Marcacao']=2;
	$estado = $_GET['estado']=1;
	$profissional = $_GET['enfermeirosLista'];
	$horas = $_GET['horasLista'];
	$data = $_GET['data'];
	
	include "../basedados.h/basedados.h";
	
		$sql = "INSERT INTO marcacao (paciente, tipo_Marcacao, estado, profissional, horas, data) VALUES ( '$paciente', '2', '1', '$profissional', '$horas', '$data')";

		$selec = mysqli_query($conn, $sql );
		
	if (mysqli_affected_rows ($conn) == 1)
			echo ('<font color="green">Consulta inserida com sucesso!</font>');
		else
			echo ('<font color="red">Ocorreu um problema com a introducao da consulta!</font>');
		header ('refresh:2;url=./paginaInicialFuncionario.php');
	?>